package org.pinwheel.agility.player;

import android.graphics.Bitmap;
import android.net.Uri;

/**
 * 版权所有 (C), 2014 <br>
 * <br>
 * All rights reserved
 *
 * @author dnwang
 * @date 2015/2/5
 * @description
 */
interface IMediaPlayer {

    public void setVideoPath(String path);

    public void setVideoURI(Uri uri);

    public Uri getCurrentURI();

    public void release(OnReleaseListener listener, Object args);

    public void start();

    public void pause();

    public void seekTo(long msec);

    public boolean isPlaying();

    public boolean isBuffering();

    public long getDuration();

    public long getCurrentPosition();

    public int getBufferPercentage();

    public int getVideoWidth();

    public int getVideoHeight();

    public void reSize(int width, int height);

    public void setVideoLayout(int layout, float aspectRatio);

    public void setOnPreparedListener(Object listener);

    public void setOnCompletionListener(Object listener);

    public void setOnErrorListener(Object listener);

    public void setOnBufferingUpdateListener(Object listener);

    public void setOnSeekCompleteListener(Object listener);

    public void setOnInfoListener(Object listener);

    public void setOnTimedTextListener(Object listener);

    public Bitmap getCurrentFrame();

    public static interface OnReleaseListener {
        public void onReleaseComplete(boolean is, Object args);
    }

}
