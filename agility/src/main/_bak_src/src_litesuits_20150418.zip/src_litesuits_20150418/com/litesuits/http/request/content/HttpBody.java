package com.litesuits.http.request.content;

/**
 * @author MaTianyu
 * @date 14-7-29
 */
public abstract class HttpBody {
    public String contentType;

    public String getContentType() {
        return contentType;
    }
}